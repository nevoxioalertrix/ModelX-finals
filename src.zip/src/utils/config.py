"""
Configuration settings for the Sri Lanka Business Intelligence Platform
"""

# News sources to scrape
NEWS_SOURCES = {
    'adaderana': {
        'url': 'http://www.adaderana.lk/news.php',
        'name': 'Ada Derana',
        'enabled': True
    },
    'dailymirror': {
        'url': 'https://www.dailymirror.lk/latest-news/159',
        'name': 'Daily Mirror',
        'enabled': True
    },
    'newsfirst': {
        'url': 'https://www.newsfirst.lk/',
        'name': 'News First',
        'enabled': True
    },
    'economynext': {
        'url': 'https://economynext.com/',
        'name': 'Economy Next',
        'enabled': True
    },
    'sundaytimes': {
        'url': 'https://www.sundaytimes.lk/',
        'name': 'Sunday Times',
        'enabled': True
    },
    'ceylontoday': {
        'url': 'https://ceylontoday.lk/',
        'name': 'Ceylon Today',
        'enabled': True
    },
    'businesstoday': {
        'url': 'https://businesstoday.lk/',
        'name': 'Business Today',
        'enabled': True
    },
    'lankabusinessonline': {
        'url': 'https://www.lankabusinessonline.com/',
        'name': 'Lanka Business Online',
        'enabled': True
    },
    'ft': {
        'url': 'https://www.ft.lk/',
        'name': 'Financial Times',
        'enabled': True
    }
}

# Category keyword mapping for article classification
CATEGORIES = {
    'political': [
        'government', 'parliament', 'minister', 'president', 'election', 'politics',
        'opposition', 'cabinet', 'legislation', 'policy', 'political', 'PM', 'vote'
    ],
    'economic': [
        'economy', 'inflation', 'rupee', 'trade', 'export', 'import', 'GDP', 'growth',
        'business', 'market', 'stock', 'bank', 'finance', 'investment', 'economic',
        'budget', 'tax', 'revenue', 'fiscal', 'monetary', 'interest rate'
    ],
    'infrastructure': [
        'infrastructure', 'road', 'highway', 'port', 'airport', 'railway', 'construction',
        'building', 'development', 'project', 'transport', 'metro', 'bridge'
    ],
    'energy': [
        'energy', 'power', 'electricity', 'fuel', 'petroleum', 'renewable', 'solar',
        'wind', 'coal', 'CEB', 'power cut', 'blackout', 'hydropower'
    ],
    'agriculture': [
        'agriculture', 'farming', 'crop', 'harvest', 'fertilizer', 'paddy', 'tea',
        'rubber', 'coconut', 'farmer', 'cultivation'
    ],
    'technology': [
        'technology', 'digital', 'IT', 'tech', 'internet', 'mobile', 'smartphone',
        'software', 'app', 'online', 'cyber', '5G', 'AI', 'automation'
    ],
    'health': [
        'health', 'hospital', 'medical', 'doctor', 'patient', 'disease', 'medicine',
        'healthcare', 'clinic', 'COVID', 'pandemic', 'vaccination'
    ],
    'education': [
        'education', 'school', 'university', 'student', 'teacher', 'exam', 'college',
        'academic', 'learning', 'educational'
    ],
    'tourism': [
        'tourism', 'tourist', 'hotel', 'travel', 'visitor', 'destination', 'resort',
        'hospitality', 'airline', 'vacation'
    ],
    'environment': [
        'environment', 'climate', 'pollution', 'forest', 'wildlife', 'conservation',
        'green', 'sustainable', 'eco', 'carbon', 'flood', 'drought', 'disaster'
    ],
    'security': [
        'security', 'police', 'crime', 'arrest', 'military', 'army', 'navy', 'force',
        'law', 'justice', 'court', 'legal', 'investigation'
    ],
    'social': [
        'protest', 'strike', 'demonstration', 'rally', 'social', 'community', 'public',
        'civil', 'rights', 'welfare', 'poverty', 'unemployment'
    ]
}

# Risk signal keywords
RISK_KEYWORDS = {
    'high': [
        'crisis', 'emergency', 'collapse', 'disaster', 'shortage', 'critical',
        'emergency', 'breakdown', 'failure', 'default', 'bankrupt'
    ],
    'medium': [
        'protest', 'strike', 'disruption', 'delay', 'concern', 'warning', 'risk',
        'threat', 'decline', 'drop', 'fall', 'decrease', 'suspend'
    ],
    'low': [
        'issue', 'problem', 'challenge', 'difficulty', 'slow', 'weak', 'uncertain'
    ]
}

# Opportunity signal keywords
OPPORTUNITY_KEYWORDS = [
    'launch', 'open', 'expand', 'growth', 'increase', 'rise', 'boost', 'improve',
    'development', 'investment', 'new', 'innovation', 'opportunity', 'success',
    'agreement', 'deal', 'partnership', 'collaboration', 'export', 'record'
]

# Scraping settings
SCRAPE_DELAY = 2  # Seconds between requests to the same source
REQUEST_TIMEOUT = 10  # Seconds to wait for response
MAX_ARTICLES_PER_SOURCE = 50  # Maximum articles to fetch per source

# Database settings
import os
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
DATABASE_PATH = os.path.join(PROJECT_ROOT, 'sri_lanka_intel.db')

# Signal detection thresholds
TRENDING_THRESHOLD = 3  # Minimum mentions to be considered trending
ANOMALY_MULTIPLIER = 2.5  # Activity must be X times normal to be anomalous
SIGNAL_LOOKBACK_HOURS = 24  # Hours to look back for signal detection
