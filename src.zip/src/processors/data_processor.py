"""
Data processor for categorizing and analyzing news articles
"""

import sys
import os
from collections import Counter
import re

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils.config import CATEGORIES
from database.db_manager import DatabaseManager

try:
    from textblob import TextBlob
    TEXTBLOB_AVAILABLE = True
except ImportError:
    TEXTBLOB_AVAILABLE = False

class DataProcessor:
    """Processes and categorizes news articles"""
    
    def __init__(self):
        self.db = DatabaseManager()
    
    def categorize_article(self, title):
        """Categorize an article based on its title"""
        title_lower = title.lower()
        
        # Count keyword matches for each category
        category_scores = {}
        for category, keywords in CATEGORIES.items():
            score = sum(1 for keyword in keywords if keyword.lower() in title_lower)
            if score > 0:
                category_scores[category] = score
        
        # Return category with highest score, or 'general' if no matches
        if category_scores:
            return max(category_scores.items(), key=lambda x: x[1])[0]
        return 'general'
    
    def analyze_sentiment(self, text):
        """Analyze sentiment of text (-1 to 1)"""
        if not TEXTBLOB_AVAILABLE:
            return 0.0
        
        try:
            blob = TextBlob(text)
            return blob.sentiment.polarity
        except:
            return 0.0
    
    def extract_keywords(self, title):
        """Extract important keywords from title"""
        # Remove common words
        stop_words = {
            'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for',
            'of', 'with', 'by', 'from', 'as', 'is', 'was', 'are', 'were', 'be',
            'been', 'being', 'have', 'has', 'had', 'do', 'does', 'did', 'will',
            'would', 'could', 'should', 'may', 'might', 'can', 'this', 'that',
            'these', 'those', 'sri', 'lanka', 'lankan', 'says', 'said'
        }
        
        # Extract words
        words = re.findall(r'\b[a-zA-Z]{4,}\b', title.lower())
        keywords = [w for w in words if w not in stop_words]
        
        return keywords
    
    def process_articles(self):
        """Process all unprocessed articles"""
        articles = self.db.get_unprocessed_articles()
        processed = []
        
        for article in articles:
            # Categorize
            category = self.categorize_article(article.title)
            
            # Sentiment analysis
            sentiment = self.analyze_sentiment(article.title)
            
            # Mark as processed
            self.db.mark_article_processed(article.id, category, sentiment)
            
            processed.append({
                'id': article.id,
                'title': article.title,
                'category': category,
                'sentiment': sentiment,
                'source': article.source
            })
        
        return processed
    
    def get_trending_topics(self, hours=24):
        """Get trending keywords from recent articles"""
        articles = self.db.get_recent_articles(hours)
        
        all_keywords = []
        for article in articles:
            keywords = self.extract_keywords(article.title)
            all_keywords.extend(keywords)
        
        # Count occurrences
        keyword_counts = Counter(all_keywords)
        
        # Return top 20
        return keyword_counts.most_common(20)
    
    def get_category_distribution(self, hours=24):
        """Get distribution of articles by category"""
        return self.db.get_category_distribution(hours)
    
    def get_sentiment_by_category(self, hours=24):
        """Get average sentiment by category"""
        from collections import defaultdict
        
        articles = self.db.get_recent_articles(hours)
        
        sentiment_data = defaultdict(list)
        for article in articles:
            if article.category and article.sentiment is not None:
                sentiment_data[article.category].append(article.sentiment)
        
        # Calculate averages
        avg_sentiment = {}
        for category, sentiments in sentiment_data.items():
            if sentiments:
                avg_sentiment[category] = sum(sentiments) / len(sentiments)
        
        return avg_sentiment
    
    def close(self):
        """Close database connection"""
        self.db.close()
