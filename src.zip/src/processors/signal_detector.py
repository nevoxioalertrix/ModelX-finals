"""
Signal detector for identifying risks, opportunities, trends, and anomalies
"""

import sys
import os
from collections import Counter
from datetime import datetime, timedelta

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils.config import RISK_KEYWORDS, OPPORTUNITY_KEYWORDS, TRENDING_THRESHOLD, ANOMALY_MULTIPLIER, SIGNAL_LOOKBACK_HOURS
from database.db_manager import DatabaseManager
from processors.data_processor import DataProcessor

class SignalDetector:
    """Detects signals from processed news data"""
    
    def __init__(self):
        self.db = DatabaseManager()
        self.processor = DataProcessor()
    
    def detect_risks(self, hours=SIGNAL_LOOKBACK_HOURS):
        """Detect risk signals from recent articles"""
        articles = self.db.get_recent_articles(hours)
        risks = []
        
        for article in articles:
            title_lower = article.title.lower()
            
            # Check for high severity keywords
            for keyword in RISK_KEYWORDS['high']:
                if keyword in title_lower:
                    risks.append({
                        'severity': 'high',
                        'description': article.title,
                        'category': article.category or 'general',
                        'source': article.source,
                        'url': article.url,
                        'detected_at': article.collected_at
                    })
                    break
            else:
                # Check for medium severity
                for keyword in RISK_KEYWORDS['medium']:
                    if keyword in title_lower:
                        risks.append({
                            'severity': 'medium',
                            'description': article.title,
                            'category': article.category or 'general',
                            'source': article.source,
                            'url': article.url,
                            'detected_at': article.collected_at
                        })
                        break
                else:
                    # Check for low severity
                    for keyword in RISK_KEYWORDS['low']:
                        if keyword in title_lower:
                            risks.append({
                                'severity': 'low',
                                'description': article.title,
                                'category': article.category or 'general',
                                'source': article.source,
                                'url': article.url,
                                'detected_at': article.collected_at
                            })
                            break
        
        # Sort by severity
        severity_order = {'high': 0, 'medium': 1, 'low': 2}
        risks.sort(key=lambda x: severity_order[x['severity']])
        
        return risks
    
    def detect_opportunities(self, hours=SIGNAL_LOOKBACK_HOURS):
        """Detect opportunity signals from recent articles"""
        articles = self.db.get_recent_articles(hours)
        opportunities = []
        
        for article in articles:
            title_lower = article.title.lower()
            
            # Check for opportunity keywords
            for keyword in OPPORTUNITY_KEYWORDS:
                if keyword in title_lower:
                    opportunities.append({
                        'description': article.title,
                        'category': article.category or 'general',
                        'source': article.source,
                        'url': article.url,
                        'detected_at': article.collected_at,
                        'sentiment': article.sentiment or 0
                    })
                    break
        
        # Sort by sentiment (most positive first)
        opportunities.sort(key=lambda x: x['sentiment'], reverse=True)
        
        return opportunities
    
    def detect_trending_topics(self, hours=SIGNAL_LOOKBACK_HOURS):
        """Detect trending topics"""
        trending_keywords = self.processor.get_trending_topics(hours)
        
        trending = []
        for keyword, count in trending_keywords:
            if count >= TRENDING_THRESHOLD:
                trending.append({
                    'topic': keyword,
                    'count': count,
                    'timeframe': f'{hours}h'
                })
        
        return trending
    
    def detect_anomalies(self):
        """Detect anomalies in news activity"""
        anomalies = []
        
        # Get article counts for different time periods
        recent_articles = self.db.get_recent_articles(hours=1)
        baseline_articles = self.db.get_recent_articles(hours=24)
        
        recent_count = len(recent_articles)
        baseline_avg = len(baseline_articles) / 24  # Average per hour
        
        # Check if recent activity is anomalously high
        if recent_count > baseline_avg * ANOMALY_MULTIPLIER:
            anomalies.append({
                'type': 'high_volume',
                'description': f'Unusual spike in news activity: {recent_count} articles in last hour (avg: {baseline_avg:.1f}/hour)',
                'severity': 'medium',
                'detected_at': datetime.now()
            })
        
        # Check for category-specific anomalies
        cat_dist = self.db.get_category_distribution(hours=1)
        baseline_dist = self.db.get_category_distribution(hours=24)
        
        for category, count in cat_dist.items():
            baseline_count = baseline_dist.get(category, 0) / 24
            if count > baseline_count * ANOMALY_MULTIPLIER and count >= 3:
                anomalies.append({
                    'type': 'category_spike',
                    'description': f'Spike in {category} news: {count} articles in last hour',
                    'category': category,
                    'severity': 'low',
                    'detected_at': datetime.now()
                })
        
        return anomalies
    
    def generate_all_signals(self):
        """Generate all types of signals"""
        return {
            'risks': self.detect_risks(),
            'opportunities': self.detect_opportunities(),
            'trending': self.detect_trending_topics(),
            'anomalies': self.detect_anomalies()
        }
    
    def close(self):
        """Close database connection"""
        self.db.close()
        self.processor.close()
