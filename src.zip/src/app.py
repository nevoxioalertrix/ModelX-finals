"""
Streamlit Dashboard for Sri Lanka Business Intelligence Platform
Run with: streamlit run app.py
"""

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta
import sys
import os

# Add src directory to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))

from database.db_manager import DatabaseManager
from processors.data_processor import DataProcessor
from processors.signal_detector import SignalDetector
from utils.config import NEWS_SOURCES

# Page configuration
st.set_page_config(
    page_title="Sri Lanka Business Intelligence",
    page_icon="🇱🇰",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS
st.markdown("""
    <style>
    .big-font {
        font-size:20px !important;
        font-weight: bold;
    }
    .metric-card {
        background-color: #f0f2f6;
        padding: 20px;
        border-radius: 10px;
        margin: 10px 0;
    }
    .risk-high {
        color: #d32f2f;
        font-weight: bold;
    }
    .risk-medium {
        color: #f57c00;
        font-weight: bold;
    }
    .risk-low {
        color: #388e3c;
        font-weight: bold;
    }
    </style>
    """, unsafe_allow_html=True)

# Initialize database and processors
@st.cache_resource
def init_system():
    db = DatabaseManager()
    processor = DataProcessor()
    detector = SignalDetector()
    return db, processor, detector

db, processor, detector = init_system()

# Sidebar
st.sidebar.title("🇱🇰 Sri Lanka Intelligence")
st.sidebar.markdown("---")

# News source filter
st.sidebar.markdown("### 📡 News Sources")

# Get all unique sources from database
all_db_sources = list(set([src for src in db.get_source_distribution(24*365).keys()]))
if not all_db_sources:
    all_db_sources = [config['name'] for config in NEWS_SOURCES.values()]

# Select all / Deselect all buttons
col_a, col_b = st.sidebar.columns(2)
if col_a.button("✓ Select All", use_container_width=True):
    st.session_state.selected_sources = sorted(all_db_sources)
if col_b.button("✗ Clear All", use_container_width=True):
    st.session_state.selected_sources = []

# Initialize session state if not exists
if 'selected_sources' not in st.session_state:
    st.session_state.selected_sources = sorted(all_db_sources)

# Multi-select for sources
selected_sources = st.sidebar.multiselect(
    "Choose sources to display:",
    options=sorted(all_db_sources),
    default=st.session_state.selected_sources,
    key='source_selector'
)

# Update session state
st.session_state.selected_sources = selected_sources

# If nothing selected, show all
if not selected_sources:
    selected_sources = sorted(all_db_sources)

# Show count
st.sidebar.caption(f"{len(selected_sources)} of {len(all_db_sources)} sources selected")

st.sidebar.markdown("---")

# Time range selector
time_range = st.sidebar.selectbox(
    "Time Range",
    ["Last 1 Hour", "Last 3 Hours", "Last 6 Hours", "Last 12 Hours", "Last 24 Hours", "Last 48 Hours", "All Time"],
    index=6
)

time_map = {
    "Last 1 Hour": 1,
    "Last 3 Hours": 3,
    "Last 6 Hours": 6,
    "Last 12 Hours": 12,
    "Last 24 Hours": 24,
    "Last 48 Hours": 48,
    "All Time": 24 * 365  # 1 year
}
hours = time_map[time_range]

# Refresh button
if st.sidebar.button("🔄 Refresh Data", use_container_width=True):
    st.cache_data.clear()
    st.cache_resource.clear()
    st.rerun()

st.sidebar.markdown("---")

# Show current data stats
st.sidebar.markdown("### Quick Stats")
total_articles_db = db.get_total_articles()
st.sidebar.info(f"Total Articles in DB: {total_articles_db}")
st.sidebar.markdown("---")
st.sidebar.markdown("### About")
st.sidebar.info(
    "Real-time situational awareness platform providing "
    "actionable insights for Sri Lankan businesses."
)

# Main content
st.title("🇱🇰 Sri Lanka Business Intelligence Platform")
st.markdown("### Real-Time Situational Awareness Dashboard")
st.markdown("---")

# Get data
def get_dashboard_data(hours, selected_sources):
    articles = db.get_recent_articles(hours=hours)
    
    # Filter by selected sources
    if selected_sources:
        articles = [a for a in articles if a.source in selected_sources]
    
    signals = db.get_recent_signals(hours=hours)
    
    # Get distributions
    cat_dist = db.get_category_distribution(hours=hours)
    source_dist = db.get_source_distribution(hours=hours)
    
    # Filter distributions by selected sources
    if selected_sources:
        source_dist = {k: v for k, v in source_dist.items() if k in selected_sources}
    
    # Get trending topics
    processor_temp = DataProcessor()
    trending = processor_temp.get_trending_topics(hours=max(hours//4, 3))
    processor_temp.close()
    
    return articles, signals, cat_dist, source_dist, trending

articles, signals, cat_dist, source_dist, trending = get_dashboard_data(hours, selected_sources)

# Key Metrics
col1, col2, col3, col4 = st.columns(4)

with col1:
    st.metric(
        label="📰 Total Articles",
        value=len(articles),
        delta=f"Last {hours}h"
    )

with col2:
    risk_signals = [s for s in signals if s.signal_type == 'risk']
    st.metric(
        label="⚠️ Risk Signals",
        value=len(risk_signals),
        delta="Active" if risk_signals else "None"
    )

with col3:
    opp_signals = [s for s in signals if s.signal_type == 'opportunity']
    st.metric(
        label="✨ Opportunities",
        value=len(opp_signals),
        delta="Detected" if opp_signals else "None"
    )

with col4:
    sources = len(source_dist)
    st.metric(
        label="📡 Active Sources",
        value=sources,
        delta="Live"
    )

st.markdown("---")

# Two column layout
col_left, col_right = st.columns([2, 1])

with col_left:
    # National Activity Indicators
    st.markdown("### 📊 National Activity Indicators")
    
    if cat_dist:
        # Category distribution chart
        df_cat = pd.DataFrame(list(cat_dist.items()), columns=['Category', 'Count'])
        df_cat = df_cat.sort_values('Count', ascending=False)
        
        fig_cat = px.bar(
            df_cat,
            x='Category',
            y='Count',
            title=f'News Coverage by Category (Last {hours}h)',
            color='Count',
            color_continuous_scale='Blues'
        )
        fig_cat.update_layout(showlegend=False, height=350)
        st.plotly_chart(fig_cat, use_container_width=True)
    else:
        st.info("No data available for the selected time range")
    
    # Trending Topics
    st.markdown("### 🔥 Trending Topics")
    
    if trending:
        # Create trending topics visualization
        trending_words = [t[0] for t in trending[:10]]
        trending_counts = [t[1] for t in trending[:10]]
        
        df_trending = pd.DataFrame({
            'Topic': trending_words,
            'Mentions': trending_counts
        })
        
        fig_trend = px.bar(
            df_trending,
            x='Mentions',
            y='Topic',
            orientation='h',
            title='Most Mentioned Topics',
            color='Mentions',
            color_continuous_scale='Reds'
        )
        fig_trend.update_layout(showlegend=False, height=400)
        st.plotly_chart(fig_trend, use_container_width=True)
    else:
        st.info("Analyzing trending topics...")
    
    # Source distribution
    if source_dist:
        st.markdown("### 📡 Coverage by Source")
        df_source = pd.DataFrame(list(source_dist.items()), columns=['Source', 'Articles'])
        
        fig_source = px.pie(
            df_source,
            values='Articles',
            names='Source',
            title='Article Distribution by Source'
        )
        fig_source.update_layout(height=350)
        st.plotly_chart(fig_source, use_container_width=True)

with col_right:
    # Risk & Opportunity Insights
    st.markdown("### ⚠️ Risk Alerts")
    
    risk_signals = [s for s in signals if s.signal_type == 'risk']
    
    if risk_signals:
        for signal in risk_signals[:5]:
            severity_class = f"risk-{signal.severity}"
            st.markdown(f"""
                <div class="metric-card">
                    <span class="{severity_class}">● {signal.severity.upper()}</span><br/>
                    <strong>{signal.category or 'General'}</strong><br/>
                    {signal.description}
                </div>
            """, unsafe_allow_html=True)
    else:
        st.success("No active risk alerts")
    
    st.markdown("---")
    
    # Opportunities
    st.markdown("### ✨ Opportunities")
    
    opp_signals = [s for s in signals if s.signal_type == 'opportunity']
    
    if opp_signals:
        for signal in opp_signals[:5]:
            st.markdown(f"""
                <div class="metric-card">
                    <span class="risk-low">● OPPORTUNITY</span><br/>
                    <strong>{signal.category or 'General'}</strong><br/>
                    {signal.description}
                </div>
            """, unsafe_allow_html=True)
    else:
        st.info("No opportunities detected")
    
    st.markdown("---")
    
    # System Status
    st.markdown("### 🔧 System Status")
    
    st.success("✓ Data Collection: Active")
    st.success("✓ Signal Detection: Active")
    st.info(f"Last Update: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

st.markdown("---")

# Operational Environment Indicators
st.markdown("### 🏢 Operational Environment Indicators")

tab1, tab2, tab3 = st.tabs(["📰 Recent News", "📈 Activity Timeline", "🔍 Detailed Analysis"])

with tab1:
    if articles:
        # Show recent articles
        for article in articles[:20]:
            sentiment = article.sentiment or 0
            sentiment_emoji = "😊" if sentiment > 0.2 else "😐" if sentiment > -0.2 else "😟"
            category = article.category or 'general'
            
            with st.expander(f"{sentiment_emoji} [{category}] {article.title[:100]}..."):
                col_a, col_b = st.columns([3, 1])
                with col_a:
                    st.markdown(f"**Source:** {article.source}")
                    st.markdown(f"**Category:** {category}")
                    st.markdown(f"**URL:** {article.url}")
                with col_b:
                    st.markdown(f"**Sentiment:** {sentiment:.2f}")
                    st.markdown(f"**Time:** {article.collected_at.strftime('%H:%M')}")
    else:
        st.info("No articles found in the selected time range")

with tab2:
    if articles:
        # Create timeline
        df_timeline = pd.DataFrame([
            {'time': a.collected_at, 'category': a.category or 'general'}
            for a in articles
        ])
        
        # Group by hour and category
        df_timeline['hour'] = pd.to_datetime(df_timeline['time']).dt.floor('H')
        timeline_counts = df_timeline.groupby(['hour', 'category']).size().reset_index(name='count')
        
        fig_timeline = px.line(
            timeline_counts,
            x='hour',
            y='count',
            color='category',
            title='Article Activity Over Time',
            labels={'hour': 'Time', 'count': 'Number of Articles', 'category': 'Category'}
        )
        fig_timeline.update_layout(height=400)
        st.plotly_chart(fig_timeline, use_container_width=True)
    else:
        st.info("Not enough data for timeline visualization")

with tab3:
    st.markdown("#### Category Breakdown")
    
    if articles:
        # Create dataframe from articles
        df_proc = pd.DataFrame([{
            'category': a.category or 'general',
            'sentiment': a.sentiment or 0,
            'title': a.title
        } for a in articles])
        
        # Category sentiment analysis
        cat_sentiment = df_proc.groupby('category').agg({
            'sentiment': 'mean',
            'title': 'count'
        }).reset_index()
        cat_sentiment.columns = ['Category', 'Avg Sentiment', 'Article Count']
        
        fig_sentiment = go.Figure()
        fig_sentiment.add_trace(go.Bar(
            x=cat_sentiment['Category'],
            y=cat_sentiment['Article Count'],
            name='Articles',
            marker_color='lightblue'
        ))
        fig_sentiment.add_trace(go.Scatter(
            x=cat_sentiment['Category'],
            y=cat_sentiment['Avg Sentiment'],
            name='Sentiment',
            yaxis='y2',
            marker_color='red'
        ))
        
        fig_sentiment.update_layout(
            title='Category Analysis: Volume vs Sentiment',
            yaxis=dict(title='Article Count'),
            yaxis2=dict(title='Avg Sentiment', overlaying='y', side='right'),
            height=400
        )
        
        st.plotly_chart(fig_sentiment, use_container_width=True)
        
        # Show table
        st.dataframe(cat_sentiment, use_container_width=True)
    else:
        st.info("No data available for analysis")

# Footer
st.markdown("---")
st.markdown(
    "<center>Sri Lanka Business Intelligence Platform | "
    "Real-Time Monitoring | Updated Every 30 Minutes</center>",
    unsafe_allow_html=True
)