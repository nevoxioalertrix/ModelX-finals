"""
Database manager for storing and retrieving news articles and signals
"""

from sqlalchemy import create_engine, Column, Integer, String, DateTime, Text, Float
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from datetime import datetime
import os
import sys

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils.config import DATABASE_PATH

Base = declarative_base()

class Article(Base):
    """Article model for storing news articles"""
    __tablename__ = 'articles'
    
    id = Column(Integer, primary_key=True)
    title = Column(Text, nullable=False)
    url = Column(String(500), unique=True, nullable=False)
    source = Column(String(100), nullable=False)
    category = Column(String(50))
    sentiment = Column(Float)
    collected_at = Column(DateTime, default=datetime.now)
    processed = Column(Integer, default=0)  # 0 = not processed, 1 = processed

class Signal(Base):
    """Signal model for storing detected signals"""
    __tablename__ = 'signals'
    
    id = Column(Integer, primary_key=True)
    signal_type = Column(String(50), nullable=False)  # risk, opportunity, trending, anomaly
    description = Column(Text, nullable=False)
    severity = Column(String(20))  # high, medium, low (for risks)
    category = Column(String(50))
    detected_at = Column(DateTime, default=datetime.now)
    meta_data = Column(Text)  # JSON string for additional data

class DatabaseManager:
    """Manages database operations"""
    
    def __init__(self, db_path=None):
        """Initialize database connection"""
        if db_path is None:
            db_path = DATABASE_PATH
        
        self.engine = create_engine(f'sqlite:///{db_path}')
        Base.metadata.create_all(self.engine)
        Session = sessionmaker(bind=self.engine)
        self.session = Session()
    
    def add_article(self, title, url, source, category=None, sentiment=None):
        """Add a new article to the database"""
        try:
            article = Article(
                title=title,
                url=url,
                source=source,
                category=category,
                sentiment=sentiment
            )
            self.session.add(article)
            self.session.commit()
            return article.id
        except Exception as e:
            self.session.rollback()
            # Likely a duplicate URL
            return None
    
    def get_unprocessed_articles(self):
        """Get all articles that haven't been processed yet"""
        return self.session.query(Article).filter(Article.processed == 0).all()
    
    def mark_article_processed(self, article_id, category=None, sentiment=None):
        """Mark an article as processed"""
        article = self.session.query(Article).filter(Article.id == article_id).first()
        if article:
            article.processed = 1
            if category:
                article.category = category
            if sentiment is not None:
                article.sentiment = sentiment
            self.session.commit()
    
    def get_recent_articles(self, hours=24):
        """Get articles from the last N hours"""
        from datetime import datetime, timedelta
        cutoff = datetime.now() - timedelta(hours=hours)
        return self.session.query(Article).filter(Article.collected_at >= cutoff).all()
    
    def get_articles_by_category(self, category, hours=24):
        """Get articles of a specific category from the last N hours"""
        from datetime import datetime, timedelta
        cutoff = datetime.now() - timedelta(hours=hours)
        return self.session.query(Article).filter(
            Article.category == category,
            Article.collected_at >= cutoff
        ).all()
    
    def add_signal(self, signal_type, description, severity=None, category=None, meta_data=None):
        """Add a new signal to the database"""
        signal = Signal(
            signal_type=signal_type,
            description=description,
            severity=severity,
            category=category,
            meta_data=meta_data
        )
        self.session.add(signal)
        self.session.commit()
        return signal.id
    
    def get_recent_signals(self, signal_type=None, hours=24):
        """Get recent signals, optionally filtered by type"""
        from datetime import datetime, timedelta
        cutoff = datetime.now() - timedelta(hours=hours)
        query = self.session.query(Signal).filter(Signal.detected_at >= cutoff)
        if signal_type:
            query = query.filter(Signal.signal_type == signal_type)
        return query.all()
    
    def get_category_distribution(self, hours=24):
        """Get distribution of articles by category"""
        from datetime import datetime, timedelta
        from sqlalchemy import func
        cutoff = datetime.now() - timedelta(hours=hours)
        
        results = self.session.query(
            Article.category,
            func.count(Article.id)
        ).filter(
            Article.collected_at >= cutoff,
            Article.category.isnot(None)
        ).group_by(Article.category).all()
        
        return {category: count for category, count in results}
    
    def get_source_distribution(self, hours=24):
        """Get distribution of articles by source"""
        from datetime import datetime, timedelta
        from sqlalchemy import func
        cutoff = datetime.now() - timedelta(hours=hours)
        
        results = self.session.query(
            Article.source,
            func.count(Article.id)
        ).filter(
            Article.collected_at >= cutoff
        ).group_by(Article.source).all()
        
        return {source: count for source, count in results}
    
    def get_total_articles(self):
        """Get total number of articles in database"""
        return self.session.query(Article).count()
    
    def close(self):
        """Close database session"""
        self.session.close()
